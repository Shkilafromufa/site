<?php
return [
    'host' => 'u937314v.beget.tech',
    'database' => 'u937314v_presfor',
    'username' => 'u937314v_presfor',
    'password' => 'rTkYA!z7TpN4',
    'admin_password' => 'admin123'
];
